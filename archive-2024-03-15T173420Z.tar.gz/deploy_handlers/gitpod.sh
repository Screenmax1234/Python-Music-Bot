cp -n .example.env .env
sudo apt install -y libopus-dev
pip3 install -U poetry
pip3 install -r requirements.txt
